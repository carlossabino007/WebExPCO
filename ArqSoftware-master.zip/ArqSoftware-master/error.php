<HTML>
<HEAD>
<TITLE>usuario no autorizado</TITLE>
</HEAD>
<BODY onLoad="setTimeout(window.close, 500000)">
<br>
<br>
<br>
<center>
<IMG SRC="img\no_autorizado.png" WIDTH=150 HEIGHT=100>
<P><h1>Usuario no autorizado</h1></P>
<P><h3>Por favor cierre el navegador e ingrese el usuario y clave correcta o por favor comuniquese con el administrador</h3></P>
<P><h3>JEFATURA RIESGO CREDITICIO</h3></P>
</BODY>
</HTML>